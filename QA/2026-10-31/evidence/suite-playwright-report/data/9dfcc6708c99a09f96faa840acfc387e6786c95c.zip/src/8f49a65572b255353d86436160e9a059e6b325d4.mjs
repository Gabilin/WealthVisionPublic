import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

const routes = ['/', '/pricing.html', '/privacy-policy.html'];
for (const route of routes) {
  test(`${route} download destinations and retired promotion`, async ({ page }) => {
    await page.goto(route);
    await expect(page.getByRole('heading', { level: 1 })).toHaveCount(1);
    const apple = page.locator('a[href="https://apps.apple.com/app/id6786717388"]');
    const google = page.locator('a[href="https://play.google.com/store/apps/details?id=com.tgdev.wealthvision"]');
    expect(await apple.count()).toBeGreaterThan(0);
    expect(await google.count()).toBeGreaterThan(0);
    await expect(apple.first()).toBeVisible();
    await expect(google.first()).toBeVisible();
    await expect(page.locator('a[href*="producthunt"], form[action*="formspree"]')).toHaveCount(0);
    await expect(page.getByText(/waitlist|founding price/i)).toHaveCount(0);
  });

  test(`${route} loads local assets and has no runtime errors`, async ({ page }) => {
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    page.on('response', response => { if (response.url().startsWith('http://127.0.0.1:4173') && response.status() >= 400) errors.push(`${response.status()} ${response.url()}`); });
    await page.goto(route);
    await page.evaluate(async () => {
      await document.fonts.ready;
      await Promise.all([...document.images].map(image => image.decode().catch(() => {})));
    });
    expect(errors).toEqual([]);
    expect(await page.locator('img').evaluateAll(images => images.every(image => image.complete && image.naturalWidth > 0))).toBe(true);
  });

  test(`${route} accessibility`, async ({ page }) => {
    await page.goto(route);
    const results = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze();
    expect(results.violations).toEqual([]);
  });

  test(`${route} responsive without horizontal overflow`, async ({ page }) => {
    for (const width of [320, 390, 768, 1024, 1440, 1920]) {
      await page.setViewportSize({ width, height: 900 });
      await page.goto(route);
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), `overflow at ${width}px`).toBe(true);
    }
  });
}

test('all money decisions expose an actual screenshot', async ({ page }) => {
  await page.goto('/');
  const tabs = page.getByRole('tab');
  await expect(tabs).toHaveCount(6);
  for (const tab of await tabs.all()) {
    await tab.click();
    await expect(tab).toHaveAttribute('aria-selected', 'true');
    await expect(page.getByRole('tabpanel')).toBeVisible();
    await expect(page.locator('#decision-screen')).toHaveAttribute('src', /images\/screens\/.+\.webp/);
    expect(await page.locator('#decision-screen').evaluate(image => image.complete && image.naturalWidth > 0)).toBe(true);
  }
});

test('screenshot tabs support keyboard navigation', async ({ page }) => {
  await page.goto('/');
  const tabs = page.getByRole('tab');
  await tabs.first().focus();
  await page.keyboard.press('ArrowRight');
  await expect(tabs.nth(1)).toBeFocused();
  await expect(tabs.nth(1)).toHaveAttribute('aria-selected', 'true');
  await page.keyboard.press('End');
  await expect(tabs.last()).toBeFocused();
  await page.keyboard.press('Home');
  await expect(tabs.first()).toBeFocused();
});

test('mobile navigation opens, follows links, and closes with Escape', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('/');
  const menu = page.getByRole('button', { name: 'Open navigation' });
  await menu.click();
  await expect(menu).toHaveAttribute('aria-expanded', 'true');
  await page.keyboard.press('Escape');
  await expect(menu).toHaveAttribute('aria-expanded', 'false');
  await menu.click();
  await page.locator('#navigation').getByRole('link', { name: 'The app', exact: true }).click();
  await expect(menu).toHaveAttribute('aria-expanded', 'false');
  await expect(page).toHaveURL(/#features$/);
});

test('FAQ opens and closes from the keyboard', async ({ page }) => {
  await page.goto('/');
  const question = page.getByText('Does WealthVision connect to my bank?', { exact: true });
  await question.focus();
  await page.keyboard.press('Enter');
  await expect(page.getByText('No. You enter the numbers you want to work with.', { exact: false })).toBeVisible();
  await page.keyboard.press('Enter');
  await expect(page.getByText('No. You enter the numbers you want to work with.', { exact: false })).not.toBeVisible();
});

test('reduced motion and JavaScript-free content remain usable', async ({ browser }) => {
  const context = await browser.newContext({ javaScriptEnabled: false, reducedMotion: 'reduce' });
  const page = await context.newPage();
  await page.goto('http://127.0.0.1:4173/');
  await expect(page.getByRole('heading', { name: 'WealthVision' })).toBeVisible();
  await expect(page.locator('#decision-screen')).toBeVisible();
  await expect(page.getByRole('link', { name: 'Pricing', exact: true }).first()).toBeVisible();
  await context.close();
});

test('local links resolve and section anchors exist', async ({ page, request }) => {
  for (const route of routes) {
    await page.goto(route);
    const links = await page.locator('a[href]').evaluateAll(anchors => anchors.map(anchor => anchor.getAttribute('href')));
    for (const href of new Set(links)) {
      if (/^(https?:|mailto:)/.test(href)) continue;
      const url = new URL(href, page.url());
      expect((await request.get(url.pathname)).status(), href).toBe(200);
      if (url.hash) {
        await page.goto(url.href);
        await expect(page.locator(url.hash)).toHaveCount(1);
      }
    }
  }
});